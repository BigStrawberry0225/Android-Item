package com.example.mediaplayer;

import java.util.ArrayList;
import java.util.List;

public class LyricsUtil {

    public static List<LrcBean> getString2List(String lrcstr){
        List<LrcBean> list =new ArrayList<>();
        String[] split =lrcstr.split("\n");
        for (int i=0;i<split.length;i++){
            String lrc=split[i];
            if(lrc.contains(".")){
                String min=lrc.substring(lrc.indexOf("[")+1,lrc.indexOf("[")+3);
                String second=lrc.substring(lrc.indexOf(":")+1,lrc.indexOf(":")+3);
                String mills=lrc.substring(lrc.indexOf(".")+1,lrc.indexOf(".")+3);
                long startTime=Long.valueOf(min)*60*1000+Long.valueOf(second)*1000+Long.valueOf(mills)*10;
                String text=lrc.substring(lrc.indexOf("]")+1);
                if(text.equals("")||text==null){
                    text="break";
                }
                LrcBean lrcBean=new LrcBean();
                lrcBean.setLrc(text);
                lrcBean.setStart(startTime);
                list.add(lrcBean);
                if(list.size()>1){
                    list.get(list.size()-2).setEnd(startTime);
                }
                if(i==split.length-1){
                    list.get(list.size()-1).setEnd(startTime+100000);
                }
            }
        }
        return list;
    }
}
