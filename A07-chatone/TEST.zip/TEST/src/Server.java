import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {


    public static JTextArea textarea=new JTextArea();
    JTextField text;

    ActionListener l=new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
            Send send=new Send();
            send.go();
        }
    };

    public static void main(String[] args) {
        Server s=new Server();
        Thread t=new Thread(new Runnable() {
            @Override
                public void run() {
                    try{
                        ServerSocket server =new ServerSocket(23000);
                        Socket socket=server.accept();

                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(socket.getInputStream(),"utf-8"));
                        String str = in.readLine();
                        textarea.append("手机："+str+"\n");
                        in.close();
                    }catch(IOException e){e.printStackTrace();}

            }
        });
        s.go();
        t.start();

    }

    public void go(){

        JFrame frame=new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel=new JPanel();
        JButton button=new JButton("发送");

        button.addActionListener(l);

        textarea =new JTextArea(10,20);
        textarea.setLineWrap(true);
        text=new JTextField();

        text.addKeyListener(new KeyAdapter(){
            public void keyPressed(KeyEvent e)
            {
                if(e.getKeyChar()==KeyEvent.VK_ENTER )   //按回车键执行相应操作;
                {
                    Send send =new Send();
                    send.go();
                }
            }
        });

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JScrollPane scroller = new JScrollPane(textarea);
        scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);


        panel.add(scroller);
        panel.add(text);
        frame.getContentPane().add(BorderLayout.CENTER,panel);
        frame.getContentPane().add(BorderLayout.SOUTH,button);

        frame.setSize(300,300);
        frame.setVisible(true);
    }

    class Send{
        public void go(){
            String str=text.getText().toString();
            if(str.equals("")||str==null)
            {
            }
            else{
                textarea.append("电脑："+str+"\n");
                try{
                    Socket s=new Socket("192.168.137.1",20000);
                    PrintWriter pout = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), "utf-8"));

                    pout.println(str);
                    pout.close();
                }catch(IOException ex){text.setText("没连上");}
                text.setText(null);
            }

        }
    }
}




