package com.example.mychat;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {
    EditText et=null;//编辑框
    Button bsend=null;//发送按钮
    LinearLayout ll;//布局
    String str;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et=(EditText)findViewById(R.id.editText1);
        bsend=(Button)findViewById(R.id.button1);
        ll=(LinearLayout)findViewById(R.id.ll);
        bsend.setText("发送");

        bsend.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                str=et.getText().toString();
                if(str.equals("")||str==null)
                {
                }
                else{
                    AddText a=new AddText();
                    a.add("手机："+str+"\n",-65536);
                     new Thread(new Runnable(){
                         @Override
                         public void run() {
                             Socket socket = null;
                             try {
                                 socket = new Socket("192.168.137.1",23000);
                                 PrintWriter send = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),"utf-8")));
                                 send.println(str);
                                 send.flush();
                                 et.setText("");
                             } catch (IOException e) {
                                 et.setText(""+e);
                                 e.printStackTrace();
                             }
                         }
                     }).start();
                }
            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    ServerSocket server=new ServerSocket(20000);
                    while(true){
                        Socket socket = server.accept();
                        BufferedReader recv = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String s=recv.readLine();
                        AddText a1=new AddText();
                        a1.add("电脑：\n"+s+"\n",-16776961);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }


//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.main, menu);
//        return true;
//    }

    class AddText{
        String str=null;
        int color=0;
        public void add(String str,int color){
            TextView show =new TextView(MainActivity.this);
            ll.addView(show);
            show.setTextSize(15);
            show.setTextColor(color);
            show.setText(str);
        }
    }


    protected void onDestroy() {
        super.onDestroy();
        android.os.Process.killProcess(android.os.Process.myPid());

    }
}