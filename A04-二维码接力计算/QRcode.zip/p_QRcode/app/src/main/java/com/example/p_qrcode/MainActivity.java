package com.example.p_qrcode;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.common.Constant;

import static com.yzq.zxinglibrary.encode.CodeCreator.createQRCode;

public class MainActivity extends AppCompatActivity {

    int N=3;
    int PreviousSum=0;
    int No=0;
    TextView scanresult;
    EditText edittext;
    EditText sumPerson;
    ImageView imageview;
    ImageButton scanBarCodeButton;
    Button generateQRCodeButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取组件
        scanresult = (TextView) this.findViewById(R.id.textview);
        edittext = (EditText) this.findViewById(R.id.edittext);
        sumPerson =(EditText)findViewById(R.id.number);
        sumPerson.setInputType(InputType.TYPE_CLASS_NUMBER);
        imageview = (ImageView) this.findViewById(R.id.imageView);
        scanBarCodeButton = (ImageButton) this.findViewById(R.id.btn_scan);
        generateQRCodeButton = (Button) this.findViewById(R.id.start);

        PermissionUtil.requestPermission(MainActivity.this,
                new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, 1);
    }

    public void onClick_analyse(View view)
    {
        Intent openCameraIntent = new Intent(MainActivity.this, CaptureActivity.class);
        startActivityForResult(openCameraIntent, 0);
    }

    public void onClick_generate(View view)
    {
        int num=Integer.parseInt(edittext.getText().toString());
        start(No,N,num,PreviousSum);
        System.out.println(num);
    }
    public void start(int no,int max,int num,int sum)
    {
        //如果是最后一个人或第一人
        if(no==0||no==2*N)
        {
            return;
        }
        //如果是第二轮
        else if(no>=N)
        {
            sum-=num;no++;
            String content=no+","+max+","+sum;
            generateQRCode(content);
        }
        //第一轮
        else {
            sum += num;no++;
            String content =no+","+max+","+sum;
            generateQRCode(content);
        }
    }

    public void generateQRCode(String content)
    {
        if (!TextUtils.isEmpty(content)) {
            Bitmap qrCode = createQRCode(content, 350, 350, null);
            imageview.setImageBitmap(qrCode);
        } else {
            Toast.makeText(MainActivity.this, "Text can not be empty", Toast.LENGTH_SHORT).show();
        }

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);

            if (resultCode == RESULT_OK) {
                // 扫描二维码/条码回传
                String content = data.getStringExtra(Constant.CODED_CONTENT);
                int no=Integer.parseInt(content.split(",")[0]);
                int max=Integer.parseInt(content.split(",")[1]);
                int sum=Integer.parseInt(content.split(",")[2]);
                No=no;
                N=max;
                PreviousSum=sum;
                if(No==2*N)
                {
                    scanresult.setText("平均数："+sum/N);
                }
            }
        }
        catch (Exception e){
            scanresult.setText(""+e);
        }

    }
}

