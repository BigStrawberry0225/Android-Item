package com.example.qqquery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView wv1 = (WebView)findViewById( R.id.id_wview1);
        // 如果不想点击时弹出新窗口，则set..一下
        wv1.setWebViewClient(new WebViewClient());
        wv1.getSettings().setCacheMode( WebSettings.LOAD_CACHE_ELSE_NETWORK);
        // 起始网址
        //wv1.loadUrl("http://192.168.2.21:8022/qqq/qqq-req.htm");

        //既然看到了入口页面的完整的、朴素的代码，可以内置到APP中。
        //wv1.loadUrl("file:///android_asset/qqq-req.htm");
        //注意当加入assets中(文件路径在.\app\src\main\assets\qqq-req.htm)的时候，把网页中的url改成全路径。
        wv1.loadUrl("file:///android_asset/qqq-req.htm");

    }
}
