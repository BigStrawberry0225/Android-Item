package com.example.gpsclock;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ActionMenuView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private Button button;
    private LocationManager manager;
    //目的地坐标
    private double golng = 0;
    private double golat = 0;
    //    当前坐标
    private double lng = 0;
    private double lat = 0;
//    判断是否到达范围之内
    private boolean arrived = false;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button)findViewById(R.id.id_button);
        mediaPlayer = MediaPlayer.create(this, R.raw.music);
        mediaPlayer.setLooping(true);
//        加载网页
        webView = (WebView) findViewById(R.id.id_webview);
        //webView.setInitialScale(250);
        webView.loadUrl("file:///android_asset/index.html");
        //        调整网页
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

//        加载js
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new MyWebChromeClient());

//        获取位置
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 10);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
        manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(true);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String provider = manager.getBestProvider(criteria, true);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(),"没有权限",Toast.LENGTH_SHORT).show();
            return;
        }

        manager.requestLocationUpdates(provider, 3000, 0, locationListener);
        Location location = manager.getLastKnownLocation(provider);

        updateWithNewLocation(location);

//        添加监听
        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                webView.loadUrl("javascript:leafletMap.panTo(["+lat+","+lng+"])");
            }
        });

        //绑定js
        webView.addJavascriptInterface(new WebAppInterface(new WebAppInterface.Callback() {
            @Override
            public void onSetValue(double lat, double lng) {
                //Toast.makeText(getApplicationContext(),"方法调用："+lat+","+lng,Toast.LENGTH_SHORT).show();
                golat = lat;
                golng = lng;
                arrived = true;
            }
        }), "data");
    }

    private void updateWithNewLocation(Location location) {
        if (location != null) {
            lat = location.getLatitude();
            lng = location.getLongitude();
        } else {
            Toast.makeText(getApplicationContext(),"无法获取地理信息",Toast.LENGTH_SHORT).show();
        }
    }

    //页面加载完
    private class MyWebChromeClient extends WebChromeClient {
        public void onProgressChanged(final WebView view, int newProgress){
            if (newProgress == 100) {
                view.loadUrl("javascript:gotoxy("+lat+","+lng+")");
                view.loadUrl("javascript:leafletMap.panTo(["+lat+","+lng+"])");
            }
            super.onProgressChanged(view,  newProgress);
        }
    }

    public final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            updateWithNewLocation(location);
            if(arrived) {
                if(Math.sqrt(Math.abs(golat - lat)*Math.abs(golat - lat) + Math.abs(golng - lng)*Math.abs(golng - lng)) < 0.001){
                    arrived = false;
                    mediaPlayer.start();
                    AlertDialog aDialog = new AlertDialog.Builder(MainActivity.this)
                            .setMessage("已到达")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    mediaPlayer.stop();
                                    mediaPlayer= MediaPlayer.create(MainActivity.this, R.raw.music);
                                }
                            }).create();
                    aDialog.show();
                }
                webView.loadUrl("javascript:gotoxy("+lat+","+lng+")");
            }
        }
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override
        public void onProviderEnabled(String provider) {}
        @Override
        public void onProviderDisabled(String provider) {}
    };

    public void setTarget(double thelat, double thelng) {
        golat = thelat;
        golng = thelng;
    }
}
