var targetlat;
    var targetlng;
    var myMarker=L.marker();
    var myCircle;
    var gotoMarker;
    function gotoxy(lat,lng){
        this.myMarker.setLatLng([lat,lng]).addTo(leafletMap)
                        .bindPopup("<b>Hello world!</b><br />I am here.").openPopup();
        //myMarker=L.marker([lat, lng])
        //增加一个圈，设置圆心、半径、样式
        if(this.myCircle){
            leafletMap.removeLayer(this.myCircle);
        }
        this.myCircle= L.circle([lat, lng], 100, {
                color: 'lightblue',
                fillColor: 'lightblue',
                fillOpacity: 0.3
        }).addTo(leafletMap);
    }
        //初始化 地图
        var url = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
        var leafletMap = L.map('mapDiv').setView([41, 123], 16);
        L.tileLayer(url, {
                maxZoom: 17,
        }).addTo(leafletMap);
        //为点击地图的事件 增加popup
        var popup = L.popup();
        function onMapClick(e) {
            this.targetlat = e.latlng.lat;
            this.targetlng = e.latlng.lng;
            if(this.gotoMarker){
                    leafletMap.removeLayer(this.gotoMarker)
                }
            this.gotoMarker = new L.Marker(e.latlng, {draggable:true});
            leafletMap.addLayer(this.gotoMarker);
            this.gotoMarker.bindPopup("<b>目的地!</b><br />Go there.").openPopup();
            leafletMap.panTo(e.latlng);
            data.setValue(this.targetlat,this.targetlng);
        }
        leafletMap.on('click', onMapClick);